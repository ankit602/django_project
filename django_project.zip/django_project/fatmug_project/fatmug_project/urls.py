
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from video_app import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('upload/', views.upload_video, name='upload_video'),
    path('videos/', views.video_list, name='video_list'),
    path('videos/<int:video_id>/', views.video_detail, name='video_detail'),
    path('videos/<int:video_id>/search/', views.search_subtitles, name='search_subtitles'),
]

# Serve media files during development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
