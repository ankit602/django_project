from django.shortcuts import render, redirect, get_object_or_404
from django.core.files.storage import FileSystemStorage
from .models import Video, Subtitle
import pysrt
import os

# Video upload with optional subtitle upload
def upload_video(request):
    if request.method == 'POST' and request.FILES['video']:
        video_file = request.FILES['video']
        subtitle_file = request.FILES.get('subtitle')  # Optional subtitle file

        fs = FileSystemStorage()
        video_filename = fs.save(video_file.name, video_file)
        video = Video.objects.create(file=video_filename, title=video_file.name)

        # If a subtitle file is uploaded, process it
        if subtitle_file:
            subtitle_filename = fs.save(subtitle_file.name, subtitle_file)
            extract_subtitles_from_srt(fs.path(subtitle_filename), video)

        return redirect('video_list')

    return render(request, 'upload_video.html')

# Extract subtitles using pysrt from a provided .srt file
def extract_subtitles_from_srt(srt_file_path, video):
    try:
        subs = pysrt.open(srt_file_path)
        for sub in subs:
            # Create Subtitle entries in the database
            Subtitle.objects.create(
                video=video,
                text=sub.text,
                timestamp=f'{sub.start.hours}:{sub.start.minutes}:{sub.start.seconds}'
            )
    except Exception as e:
        print(f"Error extracting subtitles: {e}")

# List all uploaded videos
def video_list(request):
    videos = Video.objects.all()
    return render(request, 'video_list.html', {'videos': videos})

# View details of a specific video along with its subtitles
def video_detail(request, video_id):
    video = get_object_or_404(Video, id=video_id)
    subtitles = Subtitle.objects.filter(video=video)
    return render(request, 'video_detail.html', {'video': video, 'subtitles': subtitles})

# Search subtitles based on user query
def search_subtitles(request, video_id):
    video = get_object_or_404(Video, id=video_id)
    query = request.GET.get('q', '')
    subtitles = Subtitle.objects.filter(video=video, text__icontains=query)
    return render(request, 'search_results.html', {'subtitles': subtitles, 'video': video})
